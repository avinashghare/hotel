<?php
if ( !defined( "BASEPATH" ) )
exit( "No direct script access allowed" );
class order_model extends CI_Model
{
    public function create($user,$admin,$hotel,$days,$userrate,$hotelrate,$status,$price,$checkin,$checkout,$adult,$children,$rooms,$amount,$profit)
    {
        $data=array(
                    "user" => $user,
                    "admin" => $admin,
                    "hotel" => $hotel,
                    "days" => $days,
                    "userrate" => $userrate,
                    "hotelrate" => $hotelrate,
                    "status" => $status,
                    "price" => $price,
                    "checkin" => $checkin,
                    "checkout" => $checkout,
                    "adult" => $adult,
                    "children" => $children,
                    "rooms" => $rooms,
                    "amount" => $amount,
                    "profit" => $profit
                    );
        $query=$this->db->insert( "hotel_order", $data );
        $id=$this->db->insert_id();
        if(!$query)
            return  0;
        else
            return  $id;
    }
    public function beforeedit($id)
    {
        $this->db->where("id",$id);
        $query=$this->db->get("hotel_order")->row();
        return $query;
    }
    function getsingleorder($id)
    {
        $this->db->where("id",$id);
        $query=$this->db->get("hotel_order")->row();
        return $query;
    }
    public function edit($id,$user,$admin,$hotel,$days,$userrate,$hotelrate,$status,$price,$checkin,$checkout,$adult,$children,$rooms,$amount,$profit)
    {
        $data=array(
                    "user" => $user,
                    "admin" => $admin,
                    "hotel" => $hotel,
                    "days" => $days,
                    "userrate" => $userrate,
                    "hotelrate" => $hotelrate,
                    "status" => $status,
                    "price" => $price,
                    "checkin" => $checkin,
                    "checkout" => $checkout,
                    "adult" => $adult,
                    "children" => $children,
                    "rooms" => $rooms,
                    "amount" => $amount,
                    "profit" => $profit
                    );
        $this->db->where( "id", $id );
        $query=$this->db->update( "hotel_order", $data );
        return 1;
    }
    public function delete($id)
    {
        $query=$this->db->query("DELETE FROM `hotel_order` WHERE `id`='$id'");
        return $query;
    }
    
    public function getorderstatusdropdown()
	{
		$query=$this->db->query("SELECT * FROM `orderstatus`  ORDER BY `id` ASC")->result();
		$return=array(
		);
		foreach($query as $row)
		{
			$return[$row->id]=$row->name;
		}
		
		return $return;
	}
    
}
?>
