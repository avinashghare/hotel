<?php
print_r($this->session->all_userdata());
?>